export interface iDownloadCard {
    link: string
    back?: () => void
}