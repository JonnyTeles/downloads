export interface iLayout {
    title: string,
    children: any
}