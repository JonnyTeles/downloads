export interface iButton {
    children: any
    color?: 'green' | 'blue' | 'red' | 'gray' | 'purple'
    onClick?: () => void
}