export interface iInput {
    texto: string
    value: string
    changeValue?: (value: any) => void
}